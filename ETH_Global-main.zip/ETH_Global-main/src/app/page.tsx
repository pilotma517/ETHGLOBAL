import Swap from './components/Swap';

export default function HomePage() {
  return <Swap />;
}
